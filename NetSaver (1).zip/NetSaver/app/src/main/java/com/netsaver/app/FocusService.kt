package com.netsaver.app
import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager
import com.netsaver.app.Prefs.focusMode
import com.netsaver.app.Prefs.focusPkg

/** Event-driven (no polling): fires only when the foreground app changes. */
class FocusService : AccessibilityService() {
    private val ignore by lazy {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).enabledInputMethodList
            .map { it.packageName }.toSet() + "com.android.systemui"
    }
    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (!focusMode) return
        val p = e.packageName?.toString() ?: return
        if (p in ignore || p == focusPkg) return
        focusPkg = p
        startService(Intent(this, FirewallService::class.java))
    }
    override fun onInterrupt() {}
}
