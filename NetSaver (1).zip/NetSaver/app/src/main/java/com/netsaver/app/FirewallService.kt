package com.netsaver.app
import android.net.*
import android.net.ConnectivityManager.NetworkCallback
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import com.netsaver.app.Prefs.focusMode
import com.netsaver.app.Prefs.focusPkg

/**
 * Firewall with zero speed cost: only apps that must be blocked are routed into the
 * (empty) tunnel and dropped. Every other app bypasses the VPN completely.
 * No blocked apps -> no VPN at all. Event-driven (no polling) to save battery.
 */
class FirewallService : VpnService() {
    private var tun: ParcelFileDescriptor? = null
    private var registered = false
    private val cm by lazy { getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager }
    private val cb = object : NetworkCallback() {
        override fun onCapabilitiesChanged(n: Network, c: NetworkCapabilities) = rebuild()
        override fun onLost(n: Network) = rebuild()
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (!registered) { cm.registerDefaultNetworkCallback(cb); registered = true }
        rebuild()
        return START_STICKY
    }

    private fun onWifi() =
        cm.getNetworkCapabilities(cm.activeNetwork)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true

    @Synchronized private fun rebuild() {
        val wifi = onWifi()
        val blocked: Set<String> = if (focusMode) {
            // "Current app only": block every launchable app except the open one and the "Always on" ones
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            packageManager.queryIntentActivities(i, 0).map { it.activityInfo.packageName }.toSet()
                .filter { it != focusPkg && it != packageName && Prefs.mode(this, it) != 3 }.toSet()
        } else Prefs.rules(this).filter { (_, m) -> m == 2 || (m == 1 && !wifi) }.keys
        tun?.close(); tun = null
        if (blocked.isEmpty()) return
        val b = Builder().setSession("NetSaver").addAddress("10.0.0.2", 32).addRoute("0.0.0.0", 0)
            .addAddress("fd00::2", 128).addRoute("::", 0)
        blocked.forEach { try { b.addAllowedApplication(it) } catch (_: Exception) {} }
        val fd = b.establish() ?: return
        tun = fd
        Thread {  // drain & discard = packets of blocked apps go nowhere
            try { val s = FileInputStream(fd.fileDescriptor); val buf = ByteArray(32767); while (s.read(buf) >= 0) {} } catch (_: Exception) {}
        }.start()
    }

    override fun onRevoke() { tun?.close(); stopSelf() }
    override fun onDestroy() {
        if (registered) cm.unregisterNetworkCallback(cb)
        tun?.close(); super.onDestroy()
    }
}
