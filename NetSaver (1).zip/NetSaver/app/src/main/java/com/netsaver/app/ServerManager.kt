package com.netsaver.app
import java.net.*
import kotlinx.coroutines.*

/** Picks the fastest server by measuring TCP connect time. Add your own "host:port" entries. */
object ServerManager {
    val servers = mutableListOf<String>()   // e.g. "my.server.com:443"
    private var ranked = listOf<Pair<String, Long>>()
    private var idx = 0

    suspend fun refresh() = withContext(Dispatchers.IO) {
        ranked = servers.map { s -> async { s to ping(s) } }.awaitAll().filter { it.second >= 0 }.sortedBy { it.second }
        idx = 0
    }
    private fun ping(s: String): Long = try {
        val (h, p) = s.split(":"); val t = System.nanoTime()
        Socket().use { it.connect(InetSocketAddress(h, p.toInt()), 2500) }
        (System.nanoTime() - t) / 1_000_000
    } catch (_: Exception) { -1 }

    fun current() = ranked.getOrNull(idx)
    fun next(): Pair<String, Long>? { if (ranked.isNotEmpty()) idx = (idx + 1) % ranked.size; return current() }
}
