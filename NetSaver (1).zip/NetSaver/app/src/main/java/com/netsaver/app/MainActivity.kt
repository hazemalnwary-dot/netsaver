package com.netsaver.app
import android.app.Activity
import android.content.*
import android.net.Uri
import android.net.VpnService
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.netsaver.app.Prefs.autoStart
import com.netsaver.app.Prefs.focusMode
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val vpnPerm = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == Activity.RESULT_OK) startFirewall()
    }
    private fun startFirewall() { startService(Intent(this, FirewallService::class.java)) }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        VpnService.prepare(this)?.let { vpnPerm.launch(it) } ?: startFirewall()
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { Root { startFirewall() } } } }
    }
}

@Composable fun Root(apply: () -> Unit) {
    val pager = rememberPagerState(initialPage = 1) { 3 }
    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.Center) {
            listOf("Apps", "Server", "Settings").forEachIndexed { i, t ->
                Text(t, Modifier.padding(horizontal = 14.dp), fontSize = 16.sp,
                    color = if (pager.currentPage == i) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline)
            }
        }
        HorizontalPager(pager, Modifier.weight(1f)) { p ->
            when (p) { 0 -> AppsPage(apply); 1 -> ServerPage(); else -> SettingsPage(apply) }
        }
    }
}

@Composable fun AppsPage(apply: () -> Unit) {
    val c = LocalContext.current
    val apps = remember {
        val pm = c.packageManager
        pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != c.packageName }.distinctBy { it.first }.sortedBy { it.second.lowercase() }
    }
    val modes = remember { mutableStateMapOf<String, Int>().apply { putAll(Prefs.rules(c)) } }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        items(apps) { (pkg, name) ->
            Column(Modifier.padding(vertical = 8.dp)) {
                Text(name, fontSize = 16.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Allow", "Wi-Fi only", "Block", "Always on").forEachIndexed { m, label ->
                        FilterChip(selected = (modes[pkg] ?: 0) == m, onClick = {
                            modes[pkg] = m; Prefs.setMode(c, pkg, m); apply()
                        }, label = { Text(label, fontSize = 12.sp) })
                    }
                }
            }
            HorizontalDivider()
        }
    }
}

@Composable fun ServerPage() {
    val scope = rememberCoroutineScope()
    var on by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf("No server yet") }
    fun show() { info = ServerManager.current()?.let { "${it.first}  •  ${it.second} ms" } ?: "No reachable server" }
    Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
        Box(Modifier.size(180.dp).clip(CircleShape)
            .background(if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline)
            .clickable {
                on = !on
                if (on) scope.launch { ServerManager.refresh(); show() }
                // TODO stage 2: bring up the WireGuard tunnel to ServerManager.current() here
            }, contentAlignment = Alignment.Center) {
            Text(if (on) "ON" else "OFF", fontSize = 32.sp, color = MaterialTheme.colorScheme.onPrimary)
        }
        Spacer(Modifier.height(20.dp))
        Text(info, textAlign = TextAlign.Center)
        TextButton(onClick = { ServerManager.next(); show() }, enabled = on) { Text("Change server") }
    }
}

@Composable fun SettingsPage(apply: () -> Unit) {
    val c = LocalContext.current
    var auto by remember { mutableStateOf(c.autoStart) }
    var focus by remember { mutableStateOf(c.focusMode) }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Start on boot", Modifier.weight(1f))
            Switch(auto, { auto = it; c.autoStart = it })
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Current app only (block all others)", Modifier.weight(1f))
            Switch(focus, { focus = it; c.focusMode = it; apply() })
        }
        OutlinedButton(onClick = { c.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
            Modifier.fillMaxWidth()) { Text("Enable NetSaver in Accessibility (required)") }
        Button(onClick = {
            c.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${c.packageName}")))
        }, Modifier.fillMaxWidth()) { Text("Allow background running") }
        Text("Blocked apps are dropped inside the phone. No server, no slowdown for other apps.",
            fontSize = 13.sp, color = MaterialTheme.colorScheme.outline)
    }
}
