package com.netsaver.app
import android.content.Context

/** Per-app mode: 0 = allow, 1 = Wi-Fi only (blocked on mobile data), 2 = blocked, 3 = always on (exempt in focus mode). */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("p", 0)
    fun mode(c: Context, pkg: String) = sp(c).getInt("m_$pkg", 0)
    fun setMode(c: Context, pkg: String, m: Int) {
        sp(c).edit().apply { if (m == 0) remove("m_$pkg") else putInt("m_$pkg", m) }.apply()
    }
    fun rules(c: Context): Map<String, Int> =
        sp(c).all.filterKeys { it.startsWith("m_") }.mapKeys { it.key.removePrefix("m_") }.mapValues { it.value as Int }
    var Context.autoStart: Boolean
        get() = sp(this).getBoolean("auto", true)
        set(v) { sp(this).edit().putBoolean("auto", v).apply() }
    var Context.focusMode: Boolean
        get() = sp(this).getBoolean("focus", false)
        set(v) { sp(this).edit().putBoolean("focus", v).apply() }
    var Context.focusPkg: String
        get() = sp(this).getString("fpkg", "") ?: ""
        set(v) { sp(this).edit().putString("fpkg", v).apply() }
}
