package com.netsaver.app
import android.content.*
import android.net.VpnService
import com.netsaver.app.Prefs.autoStart

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (c.autoStart && VpnService.prepare(c) == null) c.startService(Intent(c, FirewallService::class.java))
    }
}
